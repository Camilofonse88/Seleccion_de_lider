<?php
include 'election.php';
startElection();
?>
