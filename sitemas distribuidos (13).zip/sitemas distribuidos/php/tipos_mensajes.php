
<?php
define('MENSAJE_PROPOSAL', 'propuesta');
define('MENSAJE_CONFIRMACION', 'confirmacion');
define('MENSAJE_FALLO', 'fallo');
?>
